#!/bin/bash
#MODIFICATION*****************************************************
#APP="armagetronad"
#MODIFICATION*****************************************************
rm /media/sf_DrivebyDownload/lttng-traces/trace_parser_v1/results/*-socket.dat

while [ 1 ];
do 
	lsof -i | grep "$APP" >> /media/sf_DrivebyDownload/lttng-traces/trace_parser_v1/results/$APP-socket.dat;
	perl -e 'sleep(2)'
done
