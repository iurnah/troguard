#!/bin/bash

PERIOD=1
#MODIFICATION*****************************************************
#APP="armagetronad"
#MODIFICATION*****************************************************
PIDs=$(pgrep $APP)
PIDs_ARRAY=($PIDs)
PID_LEN=$(echo $PIDs | awk 'BEGIN {FS=" "} END {print NF}')

rm /media/sf_DrivebyDownload/lttng-traces/trace_parser_v1/results/*-cpu.dat
touch /media/sf_DrivebyDownload/lttng-traces/trace_parser_v1/results/$APP-cpu.dat

export PROCESSLOG_2;
export PROC_TOTAL_2;
export PROC_TOTAL_SUM_2;
export PROCESSLOG_1=0;
export PROC_TOTAL_1=0;
export PROC_TOTAL_SUM_1=0;
export TIME=0;

while [ $TIME -le 20 ]
do
	#process usage
	PROC_TOTAL_SUM_2=0
	for(( i = 0 ; i < PID_LEN ; i++ )) do

		file="/proc/${PIDs_ARRAY[i]}/stat"
		if [ -e $file ]
		then 
			PROCESSLOG_2=$(cat /proc/${PIDs_ARRAY[i]}/stat | awk '{print $14" "$15" "$16" "$17}')
			PROC_TOTAL_2=$(echo $PROCESSLOG_2 | awk '{print $1+$2+$3+$4}')
			PROC_TOTAL_SUM_2=`expr $PROC_TOTAL_SUM_2 + $PROC_TOTAL_2`
		fi
		continue
	done
	
	PROC_TOTAL=`expr $PROC_TOTAL_SUM_2 - $PROC_TOTAL_SUM_1`
	PROC_USAGE2=`expr "$PROC_TOTAL/$PERIOD" |bc -l`
	if [ $TIME == 0 ]
	then
		PROC_USAGE2=0
	fi
	Disp_PROC_Rate=`expr "scale=0; $PROC_USAGE2/1" |bc`
	#echo $APP CPU usage: $Disp_PROC_Rate Time:$TIME
	echo $TIME	$Disp_PROC_Rate >> /media/sf_DrivebyDownload/lttng-traces/trace_parser_v1/results/$APP-cpu.dat
	
	# 1 <- 2
	PROCESSLOG_1=$PROCESSLOG_2;
	PROC_USAGE1=$PROC_USAGE2;
	PROC_TOTAL_SUM_1=$PROC_TOTAL_SUM_2;
	
	sleep $PERIOD
	TIME=`expr $TIME + 1`
done  


#gnuplot -p plot.dat
