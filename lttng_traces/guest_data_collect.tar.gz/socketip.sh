#!/bin/bash
APP="firefox"

while [ 1 ];
do 
	lsof -i -n | grep "$APP" >> $APP-socket.dat;
	perl -e 'sleep(0.5)'
done

