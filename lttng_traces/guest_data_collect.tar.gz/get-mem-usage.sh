#!/bin/bash
export TIME=0;
#MODIFICATION*****************************************************
#export APP="armagetronad"
#MODIFICATION*****************************************************
rm /media/sf_DrivebyDownload/lttng-traces/trace_parser_v1/results/*-mem.dat

while [ $TIME -le 20 ]
do
	./mem_usage.sh >> /media/sf_DrivebyDownload/lttng-traces/trace_parser_v1/results/$APP-mem.dat
	
	sleep 1
	TIME=`expr $TIME + 1`
done 


