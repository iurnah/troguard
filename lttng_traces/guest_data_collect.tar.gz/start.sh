#!/bin/bash

#MODIFICATION*****************************************************
#export APP="firefox"
#export APP="chrome"
#export APP="epiphany"
#export APP="opera"
#export APP="dillo"
#export APP="armagetronad"


#export APP="wesnoth"
#export APP="beneath-a-steel-sky"
#export APP="sky"
#export APP="etracer"
#export APP="freeciv"

#export APP="kile"
#export APP="okular"
#export APP="geany"

#export APP="kmail"
#export APP="thunderbird"
export APP="evolution"


#MODIFICATION*****************************************************
rm -r /root/lttng-traces/*
lttng create rui
sleep 0.1
lttng enable-event -a -k --syscall
sleep 0.1
lttng start
#MODIFICATION*****************************************************
#$APP &
su rui -c $APP &
#su rui -c google-$APP &
#MODIFICATION*****************************************************
#su rui -c $APP &
sleep 0.1
./get-mem-usage.sh &
./get_process_usage.sh &

./socketdomain.sh &
#./socketip.sh &
sleep 30
#MODIFICATION*****************************************************
ps -ef | grep 'evolution' | awk '{print $2}' | xargs kill -9
#MODIFICATION*****************************************************
ps -ef | grep 'socketdomain' | awk '{print $2}' | xargs kill -9

lttng stop
lttng destroy

babeltrace /root/lttng-traces/$(ls /root/lttng-traces/)/ > /media/sf_DrivebyDownload/lttng-traces/txt/$APP.dat
#combine the socket info and the lttng tracing
echo trace write to log... Finished!
sort /media/sf_DrivebyDownload/lttng-traces/trace_parser_v1/results/$APP-socket.dat | uniq >> /media/sf_DrivebyDownload/lttng-traces/txt/$APP.dat 
echo combine the socket info... Finished!
#geany /media/sf_DrivebyDownload/lttng-traces/txt/trash.dat &
