/*
 * this is a place-holder for x86_64 interger syscall definition override.
 */
