#ifdef CONFIG_X86_64
#include "x86-32-syscalls-3.1.0-rc6_pointers.h"
#endif
